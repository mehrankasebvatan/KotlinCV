package ir.kasebvatan.cv.sections

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import com.varabyte.kobweb.compose.css.FontStyle
import com.varabyte.kobweb.compose.css.FontWeight
import com.varabyte.kobweb.compose.css.ObjectFit
import com.varabyte.kobweb.compose.foundation.layout.Arrangement
import com.varabyte.kobweb.compose.foundation.layout.Box
import com.varabyte.kobweb.compose.foundation.layout.Column
import com.varabyte.kobweb.compose.foundation.layout.Row
import com.varabyte.kobweb.compose.ui.Alignment
import com.varabyte.kobweb.compose.ui.Modifier
import com.varabyte.kobweb.compose.ui.modifiers.*
import com.varabyte.kobweb.compose.ui.toAttrs
import com.varabyte.kobweb.silk.components.graphics.Image
import com.varabyte.kobweb.silk.components.layout.SimpleGrid
import com.varabyte.kobweb.silk.components.layout.numColumns
import com.varabyte.kobweb.silk.components.style.breakpoint.Breakpoint
import com.varabyte.kobweb.silk.theme.breakpoint.rememberBreakpoint
import ir.kasebvatan.cv.components.header
import ir.kasebvatan.cv.components.socialBar
import ir.kasebvatan.cv.model.Sections
import ir.kasebvatan.cv.model.Theme
import ir.kasebvatan.cv.util.Constant.ABOUT_ME
import ir.kasebvatan.cv.util.Constant.FONT_FAMILY
import ir.kasebvatan.cv.util.Constant.SECTION_WIDTH
import org.jetbrains.compose.web.css.percent
import org.jetbrains.compose.web.css.px
import org.jetbrains.compose.web.dom.P
import org.jetbrains.compose.web.dom.Text
import org.jetbrains.compose.web.dom.Thead

@Composable
fun mainSection() {
    val breakpoint by rememberBreakpoint()
    Box(
        modifier = Modifier.maxWidth(SECTION_WIDTH.px).id(Sections.Home.id), contentAlignment = Alignment.TopCenter
    ) {
        mainBackground()
        mainContent(breakpoint)
    }


}

@Composable
fun mainBackground() {

    Image(
        modifier = Modifier.fillMaxSize().objectFit(ObjectFit.Cover), src = "background.svg", desc = "Background Image"
    )

}


@Composable
fun mainContent(breakpoint: Breakpoint){
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        header()
       Column(
           modifier = Modifier.fillMaxSize(),
           verticalArrangement = Arrangement.Bottom,
           horizontalAlignment = Alignment.CenterHorizontally
       ) {

           SimpleGrid(
               modifier = Modifier.fillMaxWidth(
                   if (breakpoint >= Breakpoint.MD) 80.percent else 90.percent
               ),
               numColumns = numColumns(base = 1, md = 2)
           ){
               mainText(breakpoint)
           }


       }
    }
}

@Composable
fun mainText(breakpoint: Breakpoint){
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (breakpoint > Breakpoint.MD) socialBar()
        Column {
            P(
                attrs = Modifier
                    .margin(topBottom = 0.px)
                    .fontFamily(FONT_FAMILY)
                    .fontSize(30.px)
                    .fontWeight(FontWeight.Normal)
                    .color(Theme.Primary.rgb)
                    .toAttrs()
            ) {
                Text("Hello I`m")
            }

            P(
                attrs = Modifier
                    .margin(top = 20.px, bottom = 0.px)
                    .fontFamily(FONT_FAMILY)
                    .fontSize(55.px)
                    .fontWeight(FontWeight.ExtraBold)
                    .color(Theme.DarkGray.rgb)
                    .toAttrs()
            ) {
                Text("Mehran Kasebvatan")
            }

            P(
                attrs = Modifier
                    .margin(top = 10.px, bottom = 5.px)
                    .fontFamily(FONT_FAMILY)
                    .fontSize(20.px)
                    .fontWeight(FontWeight.Bold)
                    .color(Theme.DarkGray.rgb)
                    .toAttrs()
            ) {
                Text("Mobile & Web Developer/Designer")
            }

            P(
                attrs = Modifier
                    .margin(bottom = 25.px)
                    .maxWidth(400.px)
                    .fontFamily(FONT_FAMILY)
                    .fontStyle(FontStyle.Italic)
                    .fontSize(15.px)
                    .fontWeight(FontWeight.Normal)
                    .color(Theme.DarkGray.rgb)
                    .toAttrs()
            ) {
                Text(ABOUT_ME)
            }


        }
    }
}
