package ir.kasebvatan.cv.util

object Constant {
    const val SECTION_WIDTH = 1920
    const val FONT_FAMILY = "cursive"
    const val ABOUT_ME = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua Egestas purus viverra accumsan in nisl nisi Arcu cursus vitae congue mauris rhoncus aenean vel elit scelerisque"
}