Define API routes in here.

See also: https://github.com/varabyte/kobweb#define-api-routes
